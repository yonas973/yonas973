package com.yonas.lifecontrol;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, checksBox;
    ArrayList<CheckBox> checks = new ArrayList<>();
    SharedPreferences prefs;
    TextView progress;
    String[] items = {
        "Medication as prescribed","Nicotine gum as prescribed",
        "Alcohol — followed my medical plan","Khat — followed my plan",
        "Smoking — followed my quit/reduction plan","Gym or walking",
        "English / WEI","Full Stack Programming","TryHackMe / Cybersecurity",
        "Family / quality time","Personal time used positively","Money spending recorded"
    };

    int blue=Color.rgb(31,111,235);
    int bg=Color.rgb(244,246,248);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("tracker",MODE_PRIVATE);
        build();
        load();
    }

    TextView title(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(23,32,42)); t.setPadding(0,8,0,12);
        return t;
    }
    EditText field(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16);
        e.setSingleLine(false); e.setPadding(14,10,14,10);
        e.setBackgroundColor(Color.WHITE);
        root.addView(e,new LinearLayout.LayoutParams(-1,-2));
        return e;
    }
    void card(View v){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,10,0,10); v.setPadding(18,14,18,14);
        v.setBackgroundColor(Color.WHITE); root.addView(v,p);
    }
    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15);
        return b;
    }

    void build(){
        ScrollView sv=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14,14,14,80); root.setBackgroundColor(bg); sv.addView(root);

        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(18,20,18,18); head.setBackgroundColor(blue);
        TextView h=new TextView(this); h.setText("YONAS — Life Control"); h.setTextSize(25); h.setTextColor(Color.WHITE);
        head.addView(h);
        TextView sub=new TextView(this); sub.setText("Daily Recovery • Time • Study • Money"); sub.setTextColor(Color.WHITE); sub.setTextSize(14);
        head.addView(sub); root.addView(head);

        LinearLayout c1=new LinearLayout(this); c1.setOrientation(LinearLayout.VERTICAL);
        c1.addView(title("📅 Today",19));
        TextView date=new TextView(this); date.setText(new SimpleDateFormat("EEEE, MMM d, yyyy",Locale.getDefault()).format(new Date()));
        date.setTextSize(16); c1.addView(date);
        progress=new TextView(this); progress.setTextSize(16); progress.setPadding(0,14,0,0); c1.addView(progress);
        card(c1);

        LinearLayout c2=new LinearLayout(this); c2.setOrientation(LinearLayout.VERTICAL); c2.addView(title("✅ Daily Checklist",19));
        for(String s:items){
            CheckBox cb=new CheckBox(this); cb.setText(s); cb.setTextSize(16); cb.setPadding(0,5,0,5);
            checks.add(cb); c2.addView(cb); cb.setOnCheckedChangeListener((x,y)->update());
        }
        card(c2); checksBox=c2;

        LinearLayout c3=new LinearLayout(this); c3.setOrientation(LinearLayout.VERTICAL); c3.addView(title("🧠 Craving & Triggers",19));
        EditText craving=new EditText(this); craving.setHint("Craving (0–10)"); craving.setInputType(2); c3.addView(craving);
        EditText cigs=new EditText(this); cigs.setHint("Cigarettes today"); cigs.setInputType(2); c3.addView(cigs);
        EditText khat=new EditText(this); khat.setHint("Khat: No / Yes"); c3.addView(khat);
        EditText alcohol=new EditText(this); alcohol.setHint("Alcohol: No / followed medical plan"); c3.addView(alcohol);
        EditText trigger=new EditText(this); trigger.setHint("Main trigger"); c3.addView(trigger);
        EditText helped=new EditText(this); helped.setHint("What helped me?"); helped.setMinLines(2); c3.addView(helped);
        card(c3);

        LinearLayout c4=new LinearLayout(this); c4.setOrientation(LinearLayout.VERTICAL); c4.addView(title("⏱️ How I Spent My Time",19));
        String[] times={"Recovery/substance management","Gym/walking","Full Stack Programming","TryHackMe","English/WEI","Family","Personal/healthy time","Idle/unplanned"};
        for(String s:times){ EditText e=new EditText(this); e.setHint(s+" (hours)"); e.setInputType(2|8192); c4.addView(e); }
        card(c4);

        LinearLayout c5=new LinearLayout(this); c5.setOrientation(LinearLayout.VERTICAL); c5.addView(title("💰 Money Control",19));
        for(String s:new String[]{"Daily limit","Total spent","Essential","Non-essential"}){ EditText e=new EditText(this); e.setHint(s); e.setInputType(2|8192); c5.addView(e); }
        card(c5);

        LinearLayout c6=new LinearLayout(this); c6.setOrientation(LinearLayout.VERTICAL); c6.addView(title("🌱 Today's Reflection",19));
        EditText ach=new EditText(this); ach.setHint("Today's achievement"); ach.setMinLines(2); c6.addView(ach);
        EditText goal=new EditText(this); goal.setHint("Tomorrow's goal"); goal.setMinLines(2); c6.addView(goal);
        card(c6);

        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button save=button("💾 Save"); Button reset=button("Clear");
        actions.addView(save,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(reset,new LinearLayout.LayoutParams(0,-2,1));
        save.setOnClickListener(v->saveAll()); reset.setOnClickListener(v->resetAll()); card(actions);

        LinearLayout safety=new LinearLayout(this); safety.setOrientation(LinearLayout.VERTICAL);
        safety.addView(title("🆘 Craving Tool",19));
        TextView st=new TextView(this); st.setText("DELAY 10 min → DRINK water → MOVE if allowed → REPLACE → RECORD\n\nFor alcohol withdrawal or severe symptoms, follow your medical plan and seek urgent medical care when needed."); st.setTextSize(15);
        safety.addView(st); card(safety);

        setContentView(sv);
    }

    void update(){
        int n=0; for(CheckBox c:checks) if(c.isChecked())n++;
        int p=Math.round(100f*n/checks.size());
        progress.setText("Daily checklist: "+p+"% ("+n+"/"+checks.size()+")");
    }
    void saveAll(){
        SharedPreferences.Editor e=prefs.edit();
        for(int i=0;i<checks.size();i++)e.putBoolean("c"+i,checks.get(i).isChecked());
        e.apply(); Toast.makeText(this,"Today's progress saved ✓",Toast.LENGTH_SHORT).show();
    }
    void load(){
        for(int i=0;i<checks.size();i++)checks.get(i).setChecked(prefs.getBoolean("c"+i,false));
        update();
    }
    void resetAll(){
        for(CheckBox c:checks)c.setChecked(false);
        update(); Toast.makeText(this,"Checklist cleared",Toast.LENGTH_SHORT).show();
    }
}